<div class="lista-producto float-clear" style="clear:both;">
 <ul class="list-group">
   <li class="list-group-item">
<div class="float-left"><input type="checkbox" name="item_index[]" /></div>
<div class="float-left"><input class="form-control" type="text" name="pro_nombre[]"/></div>
<div class="float-left"><input class="form-control" type="text" name="pro_precio[]" style="width:110px;" /></div>
<div class="float-left"><input class="form-control" type="text" name="pro_cantidad[]" style="width:110px;"/></div>
	</li>
 </ul> 
</div>