<?php
// Realizamos la conexion con el servidor MySQL
$connect = mysqli_connect("localhost", "root", "", "agregar_campos");
// Contamos la cantidad de input generado por el usuario
$number = count($_POST["name"]);
if($number > 1)
{
for($i=0; $i<$number; $i++)
{
if(trim($_POST["name"][$i]!= ''))
{
    // Insertamos la informacion enviada por el formulario
    $sql = "INSERT INTO tbl_nombre(nombre, fecha) VALUES('".mysqli_real_escape_string($connect, $_POST["name"][$i])."',now())";
    mysqli_query($connect, $sql);
}
}
    // Si todo es correcto, imprimimos informacion ingresada
echo "Información ingresada";
}
else
{
echo "Por favor ingrese su nombre";
}
?>